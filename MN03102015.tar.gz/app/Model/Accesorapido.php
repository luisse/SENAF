<?php
	class Accesorapido extends AppModel{
		var $name='Accesorapido';
		var $useTable=false;
	}
?>