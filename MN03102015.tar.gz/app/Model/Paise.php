<?php
App::uses('AppModel', 'Model');
/**
 * Provincia Model
 *
 * @property Provincia $Provincia
 */
class Paise extends AppModel {
	/*
	 * Funcion: permite retornar todas las provincias para su procesamiento
	 * */
}
?>