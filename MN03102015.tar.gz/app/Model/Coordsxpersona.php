<?php
App::uses('AppModel', 'Model');
/**
 * Coordsxpersona Model
 *
 * @property Coordsxpersona $Provincia
 */
class Coordsxpersona extends AppModel {
}
?>