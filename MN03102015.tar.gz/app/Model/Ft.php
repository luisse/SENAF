<?php
App::uses('AppModel', 'Model');
/**
 * Contenedorb Model
 *
 */
class Ft extends AppModel {

}
